DAA Assignment 1 C files

Compile: gcc -O2 -std=c11 daa_search.c -o daa_search
Run on Linux/macOS: ./daa_search
Run on Windows (MinGW): .\daa_search.exe after compiling with gcc -O2 -std=c11 daa_search.c -o daa_search.exe

The program tests n=1,000; 10,000; 100,000; and 1,000,000 records. It uses unsorted data for linear search and hashing, sorts a copy for binary search, and searches for the last key in the unsorted array. It verifies that all three methods find the key and prints comparison/probe counts plus machine-dependent timings. Run it on your own computer and use your own output in the final report if it differs.

Algorithms: iterative linear search, recursive binary search, hash-table search with open addressing and linear probing.
