#include <stdio.h>
#include <stdlib.h>
#include <time.h>

typedef struct { long long count; int found; } Result;
typedef struct { long long key; int used; } Entry;
long long capacity;

Result linear_search(long long a[], int n, long long key) {
    Result r = {0, 0};
    for (int i = 0; i < n; i++) {
        r.count++;
        if (a[i] == key) { r.found = 1; break; }
    }
    return r;
}

Result binary_recursive(long long a[], int low, int high, long long key) {
    Result r = {0, 0};
    if (low > high) return r;
    int mid = low + (high - low) / 2;
    r.count = 1;
    if (a[mid] == key) { r.found = 1; return r; }
    Result next;
    if (key < a[mid]) next = binary_recursive(a, low, mid - 1, key);
    else next = binary_recursive(a, mid + 1, high, key);
    r.count += next.count;
    r.found = next.found;
    return r;
}

unsigned long long hash_value(long long key, unsigned long long cap) {
    unsigned long long x = (unsigned long long)key;
    x ^= x >> 30; x *= 0xbf58476d1ce4e5b9ULL;
    x ^= x >> 27; x *= 0x94d049bb133111ebULL; x ^= x >> 31;
    return x % cap;
}

Entry *build_hash(long long a[], int n, long long *insert_probes) {
    unsigned long long cap = 1;
    while (cap < (unsigned long long)n * 2ULL) cap <<= 1;
    Entry *table = calloc((size_t)cap, sizeof(Entry));
    if (!table) return NULL;
    *insert_probes = 0;
    for (int i = 0; i < n; i++) {
        unsigned long long slot = hash_value(a[i], cap);
        while (table[slot].used) {
            (*insert_probes)++;
            slot = (slot + 1) % cap;
        }
        table[slot].key = a[i];
        table[slot].used = 1;
    }
    capacity = (long long)cap;
    return table;
}

Result hash_search(Entry table[], long long cap, long long key) {
    Result r = {0, 0};
    unsigned long long slot = hash_value(key, (unsigned long long)cap);
    while (table[slot].used && r.count < cap) {
        r.count++;
        if (table[slot].key == key) { r.found = 1; return r; }
        slot = (slot + 1) % (unsigned long long)cap;
    }
    return r;
}

int compare_ids(const void *x, const void *y) {
    long long a = *(const long long *)x, b = *(const long long *)y;
    return (a > b) - (a < b);
}

int main(void) {
    int sizes[] = {1000, 10000, 100000, 1000000};
    puts("n,linear_comparisons,binary_comparisons,hash_probes,hash_insert_probes,linear_us,binary_us,hash_us,sort_ms,hash_build_ms");
    for (int z = 0; z < 4; z++) {
        int n = sizes[z];
        long long *a = malloc((size_t)n * sizeof(long long));
        long long *sorted = malloc((size_t)n * sizeof(long long));
        if (!a || !sorted) { fprintf(stderr, "Memory allocation failed\n"); return 1; }
        for (int i = 0; i < n; i++) a[i] = 1000000000LL + 3LL * i;
        /* Shuffle all but the final key, so the selected key is last in a. */
        unsigned int seed = 12345U + (unsigned int)n;
        srand(seed);
        for (int i = n - 2; i > 0; i--) {
            int j = rand() % (i + 1);
            long long temp = a[i]; a[i] = a[j]; a[j] = temp;
        }
        for (int i = 0; i < n; i++) sorted[i] = a[i];
        clock_t s0 = clock();
        qsort(sorted, n, sizeof(long long), compare_ids);
        clock_t s1 = clock();
        long long insert_probes = 0;
        clock_t h0 = clock();
        Entry *table = build_hash(a, n, &insert_probes);
        clock_t h1 = clock();
        if (!table) { fprintf(stderr, "Hash allocation failed\n"); return 1; }
        long long key = a[n - 1];
        clock_t l0 = clock(); Result lr = linear_search(a, n, key); clock_t l1 = clock();
        clock_t b0 = clock(); Result br = binary_recursive(sorted, 0, n - 1, key); clock_t b1 = clock();
        clock_t x0 = clock(); Result hr = hash_search(table, capacity, key); clock_t x1 = clock();
        if (!lr.found || !br.found || !hr.found) { fprintf(stderr, "Test failed\n"); return 1; }
        printf("%d,%lld,%lld,%lld,%lld,%.3f,%.3f,%.3f,%.3f,%.3f\n", n, lr.count, br.count, hr.count, insert_probes,
          1e6 * (double)(l1-l0) / CLOCKS_PER_SEC,
          1e6 * (double)(b1-b0) / CLOCKS_PER_SEC,
          1e6 * (double)(x1-x0) / CLOCKS_PER_SEC,
          1e3 * (double)(s1-s0) / CLOCKS_PER_SEC,
          1e3 * (double)(h1-h0) / CLOCKS_PER_SEC);
        free(a); free(sorted); free(table);
    }
    return 0;
}
